Author: Wenyue Wang
Created: Sept 14, 2020

# Description:
This program aims to implement Kmeans method for classification

This program is built in macOS Catalina, and compiled through gcc. To compile, open terminal and type:
To install:
>> gcc main.c kmeans.c -o output.out
To compile: 
>> /output.out [filename] [cluster numer]
   e.g.  /output.out WineData_3col.txt 3


