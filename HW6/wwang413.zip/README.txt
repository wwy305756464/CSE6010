Author: Wenyue Wang, Shushu Zhao
Created: Nov 1, 2020

# Description:
This program aims to generate a nearest neighbor graph and perform the epidemic model

This program is built in macOS Catalina, and compiled through gcc. To compile, open terminal and type:

>> gcc help.c nn.c -o output.out
>> ./output.out 
