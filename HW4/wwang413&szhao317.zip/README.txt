Author: Wenyue Wang & Shushu Zhao
Date: 9/26/2020
Title: CSE6010 Homework4

This project deals to solve particular type of puzzle loosely based on Tic-Tac-Toe.
Run the test on three given dataset.

The compiler for our project is GCC, and it built on macOS Catalina . 

To compile this program, you should first locate to the folder which contains
the main.c file. 
Then use "gcc main.c search.c -o output.out"
Then "./output.out filename". 

For example, in my local laptop, I will run:
-- gcc main.c search.c -o output.out
-- ./output.out puzzle1.txt 
-- ./output.out puzzle2.txt
-- ./output.out puzzle3.txt  
Then could check the result