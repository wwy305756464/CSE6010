Author: Wenyue Wang
Created: Sept 3, 2020

# Description:
This program aims to implement a queue using a user-defined linked list structure that can achieve several interfaces, and to write a unit test to test multiple sub-functions. 

This program is built in macOS Catalina, and compiled through gcc. To compile, open terminal and type:
To install:
>> gcc unittest.c assignment2.c main.c -std=c99 -o output
To compile: 
>> double click on the output.exe and results will be shown on another terminal window


